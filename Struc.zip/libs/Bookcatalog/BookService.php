<?php

namespace Bookcatalog;

class BookService
{  

}

